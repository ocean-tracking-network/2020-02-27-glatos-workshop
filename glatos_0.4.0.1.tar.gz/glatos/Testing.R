dets_path <- system.file("extdata", "blue_shark_detections.csv", 
                         package = "glatos")
deploy_path <- system.file("extdata", "hfx_deployments.csv",
                           package = "glatos")

tag_path <- "/Users/ryangosse/Downloads/otn_nsbs_metadata_tagging_2014_jpbdlatfixes.xls"

dets <- read_otn_detections(dets_path)
tags <- prepare_tag_sheet(tag_path, 5, 2)
quarry2 <- duplicated(select(dets, detection_timestamp_utc, station, animal_id))
deploy <- read_otn_deployments(deploy_path)



morp <- convert_otn_to_att(dets, tags, deploymentObj = deploy)


dd <- left_join(dets, deploy, by = "station")
dd2 <- left_join(dets, deploy2)
dd_filter <- dd %>% filter(
  detection_timestamp_utc >= deploy_date_time,
  detection_timestamp_utc <= recover_date_time | recover_date_time %in% c(NA)
)


dd_filter2 <- dd %>% filter(
  detection_timestamp_utc >= deploy_date_time,
  detection_timestamp_utc <= coalesce(recover_date_time, last_download),
  instrumenttype == "rcvr"
)



quarry <- duplicated(select(dd_filter, detection_timestamp_utc, station, animal_id))
View(dd_filter[quarry,])
View(dd_filter[33:34,])
View(dets[quarry2,])
View(dd_filter)

mini <-min(dets$detection_timestamp_utc)
maxi <- max(dets$detection_timestamp_utc)
small_deploy <- deploy %>%
  filter(deploy_date_time <= mini,
         recover_date_time >= maxi | recover_date_time %in% c(NA, NULL),
         last_download >= maxi,
         instrumenttype == 'rcvr') %>% 
  select(station, instrumenttype, ins_model_no, deploy_date_time, last_download, recover_date_time)

quarry3 <- small_deploy %>% select(station) %>% duplicated()
View(small_deploy[quarry3,])
View(small_deploy)
dd_deduped <- dd_filter[quarry,]
View(dets[duplicated(dets %>% select(detection_timestamp_utc, station, animal_id))])
View(dd %>% filter(locality %in% c(NA, NULL)))      


?split
short_stations <- deploy %>%
  dplyr::filter(station %in% morp$Station.Information$Station.Name) 

View(short_stations)

deploy %>% select(
  station, recover_date_time, deploy_date_time, ins_model_no) %>% write.csv(file = "hfx_deploy_simplified.csv")


detectionObj <- dplyr::left_join(detectionObj %>% dplyr::select(-deploy_lat, -deploy_long), deploymentObj, by = "station")


detectionObj <- dplyr::left_join(dets %>% dplyr::select(-deploy_lat, -deploy_long )%>% dplyr::mutate(
  station = gsub("\\(lost\\/found\\)", '', station),
  receiver_sn = gsub("\\(lost\\/found\\)", '', receiver_sn)
) , deploy, by = "station")
detectionObj <- detectionObj %>% dplyr::filter(
  detection_timestamp_utc >= deploy_date_time,
  detection_timestamp_utc <= dplyr::coalesce(recover_date_time, last_download),
  instrumenttype == "rcvr"
)
short_stations <- detectionObj %>% select(
  station, recover_date_time, deploy_date_time, ins_model_no, deploy_lat, deploy_long) %>% unique()
station_split <- strsplit(short_stations$station, , split = 'X')
array <- c()
numb <- c()
for (row in station_split) {
  array <- c(array, paste(row[1], "X", sep = ''))
  numb <- c(numb, row[2])
}
short_stations <- short_stations %>% mutate(
  array =  array, number = numb
)

short_stations <- short_stations %>% select(-station)
View(short_stations)
short_stations %>% select(
  OTN_ARRAY = array,
  STATION_NO = number,
  "DEPLOY_DATE_TIME   (yyyy-mm-ddThh:mm:ss)" = deploy_date_time,
  "RECOVER_DATE_TIME (yyyy-mm-ddThh:mm:ss)" = recover_date_time,
  INS_MODEL_NO = ins_model_no,
  DEPLOY_LAT = deploy_lat,
  DEPLOY_LONG = deploy_long
) -> master_stations

install.packages("xlsx")
library("xlsx")
xlsx::write.xlsx2(master_stations, "hfx_deploy_simplified.xlsx", row.names = FALSE)
station_split <- strsplit(short_stations$station, , split = 'X')








deploy_sheet <- prepare_deploy_sheet("hfx_deploy_simplified.xlsx")
morp <- convert_otn_to_att(dets, tags, deploymentSheet = deploy_sheet)
morp2 <- convert_otn_to_att(dets, tags, deploymentObj = deploy)



class(tags)

glatos::pre
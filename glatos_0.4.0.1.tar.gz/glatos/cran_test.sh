/Library/Frameworks/R.framework/Versions/3.6/Resources/R CMD build . --resave-data
/Library/Frameworks/R.framework/Versions/3.6/Resources/R CMD check glatos_0.4.0.tar.gz --as-cran
rm -Rf /var/folders/rj/nvw1tmt94k1cll63pndh19nr0000gn/T//Rtmp9E7X79/Rd2pdfd0a346d3f4da
